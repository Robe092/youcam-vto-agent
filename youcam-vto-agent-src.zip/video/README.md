> **Current version: renders/YouCam-Demo-v4-INTERACTIVE.mp4 (1:49.5), with recorded interactions and 38 English captions. See motion-v4/README.md. Earlier versions below are preserved history.**

# YouCam — first visual edit

Local review version: **YouCam-Visual-v1-SILENT.mp4**, 2:18, 1920 × 1080, H.264, 12 fps. No audio or music. English titles and short editorial captions; full speech subtitles have not been added.

The owner requested the same two-stage workflow as PayFlow and Life After Code: review the silent visual edit first, then supply an ElevenLabs voice file. Preserve this export; fit a new version to the supplied voice rather than overwriting it.

## Material and truthfulness

- `raw/`: original CUA browser captures, captured on 17 October 2026 from the actual English interface at localhost:3000. Server explicitly forced to `YOUCAM_MODE=mock_only`; no new provider tasks were created for the video.
- Native API scenes use the saved official sample inputs and actual `cloth-v4` output in `../docs/live/`. Proof date: 16 October 2026; one completed task, 33.474 seconds. These are separately recorded artifacts, not a continuous browser run. The video labels them accordingly.
- Shopping, scores and Skin AI preview are explicitly labeled simulation. Product drawings are local illustrations, not native generated try-ons. The shopper uses local rules. Commercial figures are internal assumptions, without measured business gains.
- No provider console, account details, API key, signed result URL, or personal uploads appear in the capture set.
- This is a local visual review artifact. Public upload, final narrated export, asset redistribution rights review, and the final submission remain separate steps.

## Reproduce and review

`prepare.py` creates the continuous 18-scene timeline in `PLAN.json` and the asset hashes in `PROVENANCE.json`. Crops and optical reframing preserve the captured UI content; no fake UI interaction or fake live processing is generated.

Renderer: adapted from the owner's `deliverables/gitlab-sentinel-video/render.swift`, using the established local AVFoundation PayFlow/Sentinel workflow. Other projects were read only.

From this project's directory:

```sh
python3 video/prepare.py
swiftc -module-cache-path /tmp/youcam-swift-module-cache video/render.swift -o video/render
video/render video
swiftc -module-cache-path /tmp/youcam-swift-module-cache video/verify.swift -o video/verify
video/verify video
swiftc -module-cache-path /tmp/youcam-swift-module-cache video/decode.swift -o video/decode
video/decode video/renders/YouCam-Visual-v1-SILENT.mp4 video/verification/DECODE_CHECK.json
```

The native encoder requires normal macOS encoder access. The first sandboxed attempt failed before encoding and left a zero-byte file, preserved as `verification/failed-sandbox-encode.mp4`. The actual export uses the native encoder with local execution authorization. No media is uploaded.

Verification outputs: `verification/MEDIA_CHECK.json`, `verification/DECODE_CHECK.json`, 18 extracted scene frames and `verification/contact-sheet.jpg`. Read those results before claiming media validation.

## Voice stage

`NARRATION_EN.txt` is the continuous English voice draft to paste into ElevenLabs. It is a draft for this edit, not synthesized audio. The final scene lengths should be fitted to the actual supplied voice; do not simply stretch or truncate the narration. Suggested delivery: clear, calm, conversational, about 135–145 words per minute.

`PLAN.json` is the authoritative visual timing. The source export intentionally has zero audio tracks.

## Supplied voice synchronized — v2

The owner supplied the ElevenLabs Jerry B. recording. The synchronized export is renders/YouCam-Voice-v2.mp4 (120.750 seconds). The entire continuous voice is preserved at natural speed. All 1,449 video frames and the audio decode, and all 18 scene midpoint frames have been reviewed. See voice-v2/README.md and voice-v2/REVIEW.json. V1 remains available. Public hosting and full speech subtitles remain pending.

## English captions — v3

Latest review export: renders/YouCam-English-v3-SUBTITLED.mp4, 120.750 seconds. Forty-three English captions cover the complete 297-word voice draft. A dedicated footer replaces the former editorial captions, without resizing the UI. Audio packets are identical to v2. All frames and audio decode; all 43 captions were checked. The SRT is subtitles-v3/YouCam-English-v3.srt. See subtitles-v3/README.md. Public hosting remains pending.
