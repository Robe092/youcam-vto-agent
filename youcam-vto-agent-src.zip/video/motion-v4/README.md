# YouCam — interactive demo edit v4

Current export: `../renders/YouCam-Demo-v4-INTERACTIVE.mp4`. Target: 109.500 seconds (about 1:50), Full HD H.264, 12 fps, AAC voice, English captions. Final validation is recorded in `REVIEW.json`.

## What changed after the critique

The earlier edit mainly used one still screenshot per topic. V4 retains the opening and the separately recorded genuine Clothes API proof through 0:39, then replaces the shopping walkthrough with twelve actual temporal browser takes. The original voice is reused at natural speed, with three complete sentences removed: the repeated scoring disclaimer, the final unmodeled-profit disclaimer, and the sentence saying live Skin AI remains incomplete. Their subtitles are removed too. The mode labels, simulated skin wording, local rule-based recommendation explanation, and disclosed ROI assumptions remain truthful.

No assertion that all eleven skin scores drive the color-ranking engine is added: the actual code ranks catalog colors using the profile undertone.

## Capture method, with its limits

The same temporal image-sequence approach used in the owner's PayFlow workflow is used here: native CUA window screenshots are sampled continuously during real mouse/keyboard interaction, timestamped, and reconstructed as video. Actual cursor indications, UI transitions, dialog changes, page scrolling and changing values are present. No synthetic cursor path, fake browser UI, generated state transition, or Ken Burns movement is added to the interactive scenes.

This is **not** a native ScreenCaptureKit/30-fps screen recording. The native recorder probe was refused by macOS TCC. The working CUA route uses its existing capture access and requires no change to the owner's screen-recording settings. Sampling cadence varies (roughly 2–8 frames/s); the output video is 12 fps. Some selected takes are shortened or slightly retimed to fit the spoken topic, and brief end holds are used. The recorded input order is preserved inside each take. The volume range is focused by pointer and then adjusted with keyboard arrows; it is not a mouse drag.

`raw/manifest.json`, each take's `take.json`, `index.json`, and original PNGs retain the captured provenance. Failed `02-catalog` is preserved and excluded; `02b-catalog` is used. The first native recording permission probe and unsuccessful coordinate inputs are diagnostic attempts, not usable footage. No API key, provider console or personal upload is captured. Browser scenes show the actual local production application in explicitly forced mock mode. No new YouCam task was created.

This is an edited demonstration made from separately recorded takes. It is not one uninterrupted API-backed browser run. The real cloth-v4 result is the previously verified artifact from 16 October 2026, clearly labeled recorded API evidence.

## Assembly and voice

`PLAN_V4.json` records each visual source, interval, retiming factor and caption. `NARRATION_EN_V4.txt` is the retained narration. `YouCam-English-v4.srt` and `.ass` are the revised captions. Three whole-sentence cuts are performed inside existing quiet boundaries; speech is never accelerated or pitch-shifted. There is no music.

Two work exports failed timestamp verification and are excluded from delivery. The cause was heterogeneous pixel/range/aspect metadata across video segments, which reinitialized the combined audio/video filter graph. Intermediates now explicitly share square pixels, limited-range BT.709, pixel format and 12-fps output. Voice is assembled separately into a continuous PCM timeline before final muxing. The failed exports and intermediate attempts remain local for diagnosis.

Reproduce with `prepare.py`, `render.py`, `verify.py` in the existing local media Python environment. `render.py` preserves existing exports. Raw takes and intermediate exports are retained locally and excluded from Git and the source bundle; the final MP4 is a separate deliverable.

Review artifacts: `REVIEW.json`, `MOTION_CHECKS.json`, `CAPTION_CHECKS.json`, `verification/motion-scenes.jpg`, and full-size scene frames. Public hosting and final submission remain separate pending steps.
