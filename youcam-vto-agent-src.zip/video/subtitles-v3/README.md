# YouCam — English subtitled edit v3

Export: `../renders/YouCam-English-v3-SUBTITLED.mp4` — 120.750 seconds (about 2:01), H.264 Full HD at 12 fps. Sidecar captions: `YouCam-English-v3.srt`. ASS styling source: `YouCam-English-v3.ass`.

43 English captions cover all 297 words of the authored narration. The text is aligned back to `../NARRATION_EN.txt`, preventing ASR substitutions of names such as YouCam and Clothes API. The existing local word timestamps supply the timing; no new audio upload or generation. Script/ASR similarity: 0.96828. Captions use at most two lines and 42 characters per line, with a minimum display duration of 1.24 seconds.

The existing editorial footer, below y=970, is replaced by a dedicated dark caption band. The original UI and imagery above that boundary retain their original size. Mode labels and the recorded-proof headings remain visible. This avoids overlapping narration subtitles with the previous editorial sentences. No visual scene timing is changed from v2.

The AAC audio is copied directly from v2: compressed audio packet hashes are identical. There is no new encoding, speed change, cut, gain change or music. V1, V2 and the supplied MP3 remain preserved.

## Validation

- All 1,449 video frames and the entire audio stream decode successfully.
- All 43 cues have visible subtitle pixels, within the dedicated caption band and safe horizontal margins.
- Caption text preserves all authored words in order; no overlap between cues.
- All 43 cue midpoint bands were reviewed in `verification/all-captions.jpg`; a full-size two-line example was also inspected.
- Duration, 1920 × 1080 resolution and 12 fps verified.
- No public upload or publication.

Reports: `MEDIA_CHECK.json`, `ALL_CUES_CHECK.json`, `CAPTION_CUES.json`, `DECODE_LOG.txt`. Reproduce locally with `prepare.py`, `render.py`, `verify.py` using the same Python environment as v2. `alignment.py` is a local copy of the owner's existing exact-script caption alignment helper from the Sentinel video project; that source was read only. Only its local alignment helpers are called, without external transcription services.
