# YouCam — synchronized voice edit v2

Export: `../renders/YouCam-Voice-v2.mp4` — 120.750 seconds (about 2:01), H.264 Full HD, 12 fps, AAC mono 48 kHz.

Voice: the owner's supplied ElevenLabs Jerry B. MP3, preserved locally as `source-jerry-youcam.mp3`. It is used in full, continuously, at natural speed. No speech trimming, tempo change, pitch change or inserted pauses. Only AAC transcoding and 1.501 seconds of silence after the end of the original audio. No music. The silent v1 and original MP3 remain intact.

All 18 visual scenes have been fitted to the spoken topics, using local word timestamps. `SYNC_LEDGER.json` records each source interval, new interval and spoken anchor. Only the edited screenshots and optical reframing change duration. The recorded native API proof and explicit simulation labels are preserved.

Processing is entirely local: FFmpeg for decoding/editing, faster-whisper base.en for word timestamps. The recognition model was downloaded; the user's audio was not uploaded. The initial PyAV 19 metadata-argument incompatibility was resolved by passing locally decoded PCM samples to the transcriber. ASR approximations of product names are not treated as speech defects or burnt into captions.

## Checks

- All 1,449 video frames and the full audio track decode successfully.
- 18 representative scene frames extracted and visually reviewed in a contact sheet.
- Audio waveform correlation with the complete source: 0.9999758 after AAC re-encoding, with no time offset.
- Source audio: 119.249 seconds. Final export: 120.750 seconds. Tail padding is silent.
- Final audio peak: −5.91 dBFS; no digital clipping detected.
- No full speech subtitles have been added. Existing editorial captions remain visible.
- No upload, publication or new provider generation.

These checks establish technical suitability and synchronization. The owner's preferred voice tone remains a listening preference. No rerecording is technically required for timing.

Reports: `REVIEW.json`, `AUDIO_ANALYSIS.txt`, `DECODE_CHECK.txt`. Reproduce with `analyze.py`, `assemble.py`, `verify.py` in a Python environment containing imageio-ffmpeg, faster-whisper, numpy, av and Pillow. Export scripts preserve existing output versions.
